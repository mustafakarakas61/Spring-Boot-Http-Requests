package com.mtm.test.mustafa.exception;

public class MtmException extends Exception{
}
