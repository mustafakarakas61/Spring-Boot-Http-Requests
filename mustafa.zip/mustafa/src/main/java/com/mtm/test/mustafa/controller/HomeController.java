package com.mtm.test.mustafa.controller;

import com.mtm.test.mustafa.entity.DefCity;
import com.mtm.test.mustafa.exception.MtmException;
import com.mtm.test.mustafa.repository.DefCityRepository;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
public class HomeController {

    private DefCityRepository cityRepository;
    private JdbcTemplate jdbcTemplate;

    public HomeController(DefCityRepository cityRepository,JdbcTemplate jdbcTemplate) {
        this.cityRepository = cityRepository;
        this.jdbcTemplate = jdbcTemplate;
    }

    @GetMapping("/cities")
    public Iterable<DefCity> cityList() {

        Iterable<DefCity> data = this.cityRepository.findAll();


        return data;
    }

    @PutMapping("/city/{id}")
    public DefCity cityUpdate(@PathVariable Integer id, @RequestParam String name) throws Exception {

        Optional<DefCity> data = this.cityRepository.findById(id);

        if (data.isPresent()) {
            data.get().setName(name);
            this.cityRepository.save(data.get());
            return data.get();
        }
        else {
            throw new Exception("Kayıt Bulunamadı");
        }
    }

    @GetMapping(path = "/")
    public String homePage() {

        //Optional<DefCity> data = this.cityRepository.findById(1);

        //DefCity dat = this.cityRepository.findByNameAndId("İstanbul", 1);

        this.jdbcTemplate.update("update def_city set name = 'İstanbul 2' where id = 1");

        return "update calisti";

    }

}
